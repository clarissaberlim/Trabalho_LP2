
import java.util.ArrayList;

public class Musica implements Comparable {
    private String titulo;
    private String artista;
    private String idiomaOriginal;
    private GeneroMusical genero;
    private ArrayList<Cifra> cifras;
    private ArrayList<Traducao> traducoes;

    public Musica(String artista, GeneroMusical genero, String idiomaOriginal, String titulo) {
        this.artista = artista;
        this.genero = genero;
        this.idiomaOriginal = idiomaOriginal;
        this.titulo = titulo;
    }

    public void exibirCifras() {

    }

    public void exibirTraducoes() {

    }

    @Override
    public int compareTo(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean equals(Object obj) {

    }

}