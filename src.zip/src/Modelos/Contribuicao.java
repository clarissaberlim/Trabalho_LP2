
public interface Contribuicao {
    public boolean publicar(Object obj);
    public boolean editar(Object obj);
    public boolean remover(Object obj);
}