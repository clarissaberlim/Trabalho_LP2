
public enum GeneroMusical {
    POP, ROCK, MPB, SAMBA, JAZZ;
}