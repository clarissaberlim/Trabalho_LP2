
public class Traducao implements Contribuicao{
    private String id;
    private String textoTraduzido;
    private String idioma;
    private Usuario usuarioAutor;
    private Musica musica;

    public Traducao(String id, String idioma, Musica musica, String textoTraduzido) {
        this.id = id;
        this.idioma = idioma;
        this.musica = musica;
        this.textoTraduzido = textoTraduzido;
        //colocar usuario aqui
    }





}