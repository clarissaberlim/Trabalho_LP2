
public class Colaborador extends Usuario {

    public Colaborador(String email, String nome, String usuario) {
        super(email, nome, usuario);
    }

    @Override
    public void contribuir() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}