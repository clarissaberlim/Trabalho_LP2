
import java.time.LocalDate;

public class Cifra implements Contribuicao {
    private String id;
    private String conteudo;
    private LocalDate dataEnvio;
    private Usuario usuarioAutor; //duvida
    private Musica musica;
    //private ArrayList<Comentario> comentario

    public Cifra(String conteudo, LocalDate dataEnvio, String id, Musica musica, Usuario usuarioAutor) {
        this.conteudo = conteudo;
        this.dataEnvio = dataEnvio;
        this.id = id;
        this.musica = musica;
        this.usuarioAutor = usuarioAutor;
    } //na main quando a pessoa quiser incluir uma cifra, primeiro tem que verificar se a musica já ta cadastrada
    
            

}