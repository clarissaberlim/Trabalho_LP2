
import java.time.LocalDate;

public abstract class Usuario {
    protected String nome;
    protected String email;
    protected String usuario;
    protected LocalDate dataCadastro;

    public Usuario(String email, String nome, String usuario) {
        this.email = email;
        this.nome = nome;
        this.usuario = usuario;
        this.dataCadastro = LocalDate.now(); //obs
    }

    public abstract void contribuir(); //tem que ver depois os parâmetros
    
}